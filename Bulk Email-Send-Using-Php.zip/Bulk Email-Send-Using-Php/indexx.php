<?php 
include('welcome.php');
include('includes/header.php');
include('includes/navigation.php');
?>

<style type="text/css">
    .py-5{
    width:100% ;
    height: 130vh;
    background-image:linear-gradient(rgba(0,0,0,0.75),rgba(0,0,0,0.75)),url(bg-2.jpg) ;
    background-size:cover;
    background-position:center;
}
</style>
<div class="py-5">
</div>

<?php 
include('includes/footer.php');
?>