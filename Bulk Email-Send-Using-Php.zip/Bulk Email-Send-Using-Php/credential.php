<?php 
	/*Update credentials*/
	define('your email account.com', '');
	define('Your Password', '');
 ?>